
import java.io.*;
import java.util.*;

/**
 * 
 */
public class CtaCte {

    /**
     * Default constructor
     */
    public CtaCte() {
    }

    /**
     * 
     */
    private double saldo;

}